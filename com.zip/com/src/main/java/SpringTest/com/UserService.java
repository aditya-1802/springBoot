package SpringTest.com;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;
    
    // Save a user
    public Employees saveUser(Employees user) {
        return userRepository.save(user);
    }

    // Get all users
    public List<Employees> getAllUsers() {
        return userRepository.findAll();
    }

    // Get user by ID
    public Optional<Employees> getUserById(Integer id) {
        return userRepository.findById(id);
    }

    // Delete user by ID
    public void deleteUser(Integer id) {
        userRepository.deleteById(id);
    }
    
 // find ID by name
    public List<Employees> findID(String name) {
        return userRepository.findByNameNative(name);
    }
}
