package SpringTest.com;


import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;



@RequestMapping("/users")
@Controller
public class GreetingController {
	
	@Autowired
    private UserService userService;
	
	
	private static final String template = "Hello, %s!";
	private final AtomicLong counter = new AtomicLong();
	
	private static final Logger log = LoggerFactory.getLogger(GreetingController.class);

	private static final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");

	@GetMapping("/greeting")
	public Greeting greeting(@RequestParam(value = "name", defaultValue = "World") String name) {
		return new Greeting(counter.incrementAndGet(), String.format(template, name));
	}
	
	@GetMapping("/{id}")
    public Optional<Employees> getUser(@PathVariable Integer id) {
        return userService.getUserById(id);
    }
	
	@GetMapping("/login")
    public String showLoginForm() {
        return "index"; // loads login.html
    }

    @PostMapping("/login")
    public String processLogin(@RequestParam String username,
                               @RequestParam String password,Model model) {
        Employees user = new Employees();
//        user.setID(10);
        user.setName(username);
        user.setPosition(password);
        List<Employees> finduser = userService.findID(username);
        System.out.println("FindNameByID."+finduser.toString());
        
        if(finduser != null && !finduser.isEmpty() &&finduser.get(0).getName().equals(username) && finduser.get(0).getPosition().equals(password)) {
        	return "home"; // Redirect after saving
        }
        else {
        	model.addAttribute("error", "Invalid username or password.");
//        	userService.saveUser(user); // Save user to DB
            return "index";
        }
    }
    
    @GetMapping("/success")
    public String successPage() {
        System.out.println("Navigating to success page.");
        return "success";
    }
    
    @GetMapping("/signup")
    public String showSignupForm() {
        return "signup"; // loads signup.html
    }

    @PostMapping("/signup")
    public String processSignup(@RequestParam String username, 
                                @RequestParam String password, 
                                @RequestParam String confirmPassword, 
                                Model model) {

        // Check if passwords match
        if (!password.equals(confirmPassword)) {
            model.addAttribute("error", "Passwords do not match.");
            return "signup";  // Stay on the signup page with an error message
        }

        // Check if username is already taken
        if (userService.findID(username) != null && !userService.findID(username).isEmpty()) {
            model.addAttribute("error", "Username already exists.");
            return "signup";  // Stay on the signup page with an error message
        }

        // Create new user
        Employees newUser = new Employees();
        newUser.setName(username);
        newUser.setPosition(password); // or use a separate field like 'password' for security

        // Save user to the database
        userService.saveUser(newUser);

        return "redirect:/users/login";  // Redirect to login page after successful sign up
    }

	
//	(@RequestBody Employees employee ) 
//	(@RequestParam(value = "name", defaultValue = "World") String name,
//            @RequestParam(value = "position", defaultValue = "Unknown") String position,
//            @RequestParam(value = "id", defaultValue = "0") int id)
	
	
}
