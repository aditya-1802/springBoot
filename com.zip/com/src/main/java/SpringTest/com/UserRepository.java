package SpringTest.com;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface UserRepository extends JpaRepository<Employees, Integer> {
    // Custom query methods can be added here if needed
//	@Query("SELECT ID FROM User u WHERE u.name = :name")
//    List<Employees> findByName(@Param("name") String name);
	
	 @Query(value = "SELECT * FROM Employees WHERE name = :name", nativeQuery = true)
	 List<Employees> findByNameNative(@Param("name") String name);
}
