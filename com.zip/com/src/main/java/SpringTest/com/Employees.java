package SpringTest.com;

import org.springframework.stereotype.Component;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Component
public class Employees {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonProperty("ID")
    private int ID;
    
    @JsonProperty("Name")
    private String Name;
    
    @JsonProperty("Position")
    private String Position;
    
	public int getID() {
		return ID;
	}
	
	@Override
	public String toString() {
		return "Employees [ID=" + ID + ", Name=" + Name + ", Position=" + Position + "]";
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getPosition() {
		return Position;
	}
	public void setPosition(String position) {
		Position = position;
	}
    
    
    
    
    
}
