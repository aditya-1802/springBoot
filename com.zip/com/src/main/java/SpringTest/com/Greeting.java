package SpringTest.com;

public record Greeting (long id , String name){

}
